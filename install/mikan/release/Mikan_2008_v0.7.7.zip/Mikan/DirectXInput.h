#include <dinput.h>
#include <DxErr.h>
#include "keymap.h"

//�����N���郉�C�u�����̎w��BVC����B
#pragma comment(lib,"dinput8.lib")
#pragma comment(lib,"dxguid.lib")

#ifdef _DEBUG
 #pragma comment(lib,"DirectXInputD.lib")
#else
 #pragma comment(lib,"DirectXInput.lib")
#endif

#ifndef KB_KEYMOUNT

//�L�[�{�[�h�̃L�[��
#define KB_KEYMOUNT 0xEE
//�Q�[���p�b�h�̃L�[�̐�
//#define PAD_KEYMOUNT  16
//���͂̍ő�l
#define KB_MAXINPUT 0x7FFFFFFF
//���͂̍ő�l
#define PAD_MAXINPUT 0x7FFFFFFF

#define DX_RELEASE(r) { if( r ){ ( r )->Release(); } r = NULL; }
#define DX_FREE(f)    { if( f ){ free( f ); } f = NULL; }

#define PAD_MAX 16

#define CLASSDEF_DIRECTX_INPUT class DirectXInput

enum
{
  PAD_UP    = 0,
  PAD_DOWN,
  PAD_LEFT,
  PAD_RIGHT,
  PAD_A,
  PAD_B,
  PAD_C,
  PAD_D,
  PAD_E,
  PAD_F,
  PAD_G,
  PAD_H,
  PAD_I,
  PAD_J,
  PAD_K,
  PAD_L,
  PAD_KEYMOUNT
};
// �L�[�̏��
/*enum
{
  PAD_NONE  = 0x00,
  PAD_TRIG  = 0x01,
  PAD_PUSH  = 0x02,
  PAD_PULL  = 0x04,
};*/

BOOL CALLBACK JoystickCallback( const DIDEVICEINSTANCE* lpdi, void *obj );

class DirectXInput
{
private:
  char                  KeyBuf[ 256 ];
  int                   Key[ 256 ];
  char                  PadBuf[ PAD_MAX ][ PAD_KEYMOUNT ];
  int                   Pad[ PAD_MAX ][ PAD_KEYMOUNT ];
  char                  UsePad[ PAD_MAX ];
  char                  AnyPush[ PAD_MAX ];
  DIDEVCAPS             PadDevCaps[ PAD_MAX ];
  unsigned int          PadNum;
  HWND                  WindowHandle;
public:
  unsigned int          CountPadNum;
  LPDIRECTINPUT8        lpDIKey, lpDIPad;
  LPDIRECTINPUTDEVICE8  g_pDIDevKey, g_pDIDevPad[ PAD_MAX ];
  HRESULT               hr;
  DirectXInput( void );
  virtual ~DirectXInput( void );
  virtual int InitKeyboard( HWND wh, HINSTANCE ih );
  virtual int InitGamepad( HWND wh, HINSTANCE ih );
  virtual int SetUp( HWND wh, HINSTANCE ih );
  virtual int RecognitionGamepad( int resume = 1 );
  virtual int GetKeyNum( int keynum );
  virtual int UpdateKeyStatus( void );
  virtual int UpdateKeyInput( void );
  virtual int GetPadNum( unsigned int padnum, int button );
  virtual int GetPadMount( void );
  virtual int PadPush( unsigned int padnum, int button );
  virtual int UpdatePadStatus( unsigned int padnum );
  virtual int UpdatePadInput( void );
};

#endif
