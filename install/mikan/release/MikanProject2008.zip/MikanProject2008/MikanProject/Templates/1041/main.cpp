#include <Mikan.h>

void SystemInit( void )
{
}

void UserInit( void )
{
}

int MainLoop( void )
{
  //��ʃN���A�B
  MikanDraw->ClearScreen();

  return 0;
}

void CleanUp( void )
{
}
