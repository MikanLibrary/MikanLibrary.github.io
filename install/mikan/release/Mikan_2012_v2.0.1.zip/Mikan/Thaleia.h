#pragma once

#include "IFile.h"
#include "IAudioHandler.h"
#include "IVoice.h"
#include "functions.h"
