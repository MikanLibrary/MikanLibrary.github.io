#include "MikanLiblary.h"

extern CLASSDEF_MIKAN_LIBLARY       *MikanSystem;
extern CLASSDEF_MIKAN_WINDOW        *MikanWindow;
extern CLASSDEF_MIKAN_DIRECTX_DRAW  *MikanDraw;
extern CLASSDEF_MIKAN_DIRECTX_INPUT *MikanInput;
