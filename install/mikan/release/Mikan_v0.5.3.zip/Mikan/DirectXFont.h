#ifndef CLASSDEF_DIRECTX_FONT

#define CLASSDEF_DIRECTX_FONT class DirectXFont

#define MAX_FONT 0xFF
#define DEFAULT_FONT "�l�r�@�S�V�b�N"

struct FONTDATA
{
  char use;
  int height;
  unsigned int width;
  unsigned int weight;
  unsigned int miplevel;
  bool italic;
  unsigned long charset;
  unsigned long outputprecision;
  unsigned long quality;
  unsigned long pitchandfamily;
  char fontname[64];
  ID3DXFont *D3DFont;
  RECT rect;
  unsigned long color;
};

class DirectXFont
{
public:
  IDirect3DDevice9 *D3DDev;
  struct FONTDATA FontData[ MAX_FONT ];

  DirectXFont( void );
  virtual ~DirectXFont( void );

  virtual int CleanUp( void );
  virtual int Recover( void );
  virtual int Init( IDirect3DDevice9 *D3DDev );
  virtual int CreateFont( int fontnum, char *fontname, int size = 10, unsigned long color = 0xFFFFFFFF );
  virtual int CreateFont( int fontnum, int size = 10, unsigned long color = 0xFFFFFFFF );
//  virtual int CreateFont( int fontnum );

//  virtual int Print( int fontnum, char *str );
  virtual int Print( int fontnum, int x, int y, char *str );
//  virtual int Begin( int fontnum, int x, int y );
  virtual int Begin( int fontnum );
  virtual int End( void );

  virtual int SetFont( char *fontname, int size, int option = 0 );
  virtual int MakeTexture( int num, unsigned char *c, int length );
  virtual int ControlSize( int size );
};

#endif
