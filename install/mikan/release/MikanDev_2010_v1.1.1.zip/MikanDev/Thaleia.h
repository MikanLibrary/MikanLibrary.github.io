#pragma once

#pragma comment(lib, "dsound.lib")
#pragma comment(lib, "dxguid.lib")

#include <string.h>
#include <tchar.h>
#include <dsound.h>

#ifdef _DEBUG
	//�f�o�b�O���̒ǉ��̈ˑ��t�@�C��
	#pragma comment(lib, "Thaleia_d.lib")
#else
	//�����[�X���̒ǉ��̈ˑ��t�@�C��
	#pragma comment(lib, "Thaleia.lib")
#endif

namespace Thaleia
{
	enum FileType
	{
		FILETYPE_UNKNOWN,
		FILETYPE_WAVE,
		FILETYPE_MP3,
		FILETYPE_OGG,
		FILETYPE_MIDI
	};

	struct WaveFormatEx
	{
		unsigned short format_type;   /* format type */
		unsigned short channels;      /* number of channels (i.e. mono, stereo...) */
		unsigned long  sample_rate;   /* sample rate */
		unsigned long  average_bytes; /* average bytes per second for buffer estimation */
		unsigned short block_align;   /* block size of data */
		unsigned short sample_size;   /* number of bits per sample of mono data */
		unsigned short extend_size;   /* the count in bytes of the size of extra information (after cbSize) */
	};

	class IFile
	{
	public:
		virtual ~IFile(){}
		virtual unsigned long read(void* buffer, unsigned long length) = 0;
		virtual unsigned long getSize() = 0;
		virtual unsigned long tell() = 0;
		virtual bool seek(long long offset, bool relatively = false) = 0;
	};

	class IPcmHandler
	{
	public:
		virtual ~IPcmHandler(){}
		virtual bool bind(IFile* file) = 0;
		virtual IFile* unbind() = 0;
		virtual unsigned long read(void* buffer, unsigned long length) = 0;
		virtual unsigned long tell() = 0;
		virtual void seek(int offset, bool relatively = false) = 0;
		virtual unsigned long getSize() = 0;
		virtual size_t getWaveFormatEx(void* format, size_t size) = 0;
		virtual int getTagLength() = 0;
		virtual const char* getTag(int index) = 0;
	};

	class IPcmPlayer
	{
	public:
		virtual ~IPcmPlayer(){}
		virtual bool bind(IPcmHandler* pcm) = 0;
		virtual IPcmHandler* unbind() = 0;
		virtual void play() = 0;
		virtual void pause() = 0;
		virtual void stop() = 0;
		virtual unsigned long tell() = 0;
		virtual void seek(unsigned long millisecond) = 0;
		virtual double getVolume() = 0;
		virtual double getPan() = 0;
		virtual unsigned int getFrequency() = 0;
		virtual bool getLoop() = 0;
		virtual bool getLoopTime(unsigned long* start, unsigned long* end) = 0;
		virtual void setVolume(double volume) = 0;
		virtual void setPan(double pan) = 0;
		virtual void setFrequency(unsigned int frequency) = 0;
		virtual bool setLoop(bool enable) = 0;
		virtual bool setLoopTime(unsigned long start, unsigned long end) = 0;
		virtual bool isPlaying() = 0;
	};

	extern IFile* createFile(const char* file_path, bool cache);
	extern IPcmHandler* createPcmHandler(FileType file_type);
	extern IPcmPlayer* createPlayer(IDirectSound* directsound, bool ring);
	extern FileType suggestFileType(IFile* file);
};
