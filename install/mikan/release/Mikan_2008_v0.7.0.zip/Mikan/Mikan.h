#define USEMIKANLIBRARY
#include "MikanLiblary.h"

extern CLASSDEF_MIKAN_SYSTEM        *MikanSystem;
extern CLASSDEF_MIKAN_WINDOW        *MikanWindow;
extern CLASSDEF_MIKAN_DIRECTX_DRAW  *MikanDraw;
extern CLASSDEF_MIKAN_DIRECTX_INPUT *MikanInput;
extern CLASSDEF_SYSTEM              *_MikanSystem;
extern CLASSDEF_WINDOW              *_MikanWindow;
extern CLASSDEF_DIRECTX_DRAW        *_MikanDraw;
extern CLASSDEF_DIRECTX_INPUT       *_MikanInput;
