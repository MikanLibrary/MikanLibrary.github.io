#ifndef USEMIKANLIBRARY
#define USEMIKANLIBRARY
#define _MIKANDEV
#include "MikanDev_MikanLibrary.h"

//���J�N���X
extern CLASSDEF_MIKAN_SYSTEM        *MikanSystem;
extern CLASSDEF_MIKAN_WINDOW        *MikanWindow;
extern CLASSDEF_MIKAN_DIRECTX_DRAW  *MikanDraw;
extern CLASSDEF_MIKAN_DIRECTX_3D    *Mikan3D;
extern CLASSDEF_MIKAN_DIRECTX_INPUT *MikanInput;
extern CLASSDEF_MIKAN_DIRECTX_SOUND *MikanSound;
//extern CLASSDEF_MIKAN_NETWORK       *MikanNet;
//����J�N���X
extern CLASSDEF_SYSTEM              *_MikanSystem;
extern CLASSDEF_WINDOW              *_MikanWindow;
extern CLASSDEF_DIRECTX_DRAW        *_MikanDraw;
extern CLASSDEF_DIRECTX_3D          *_Mikan3D;
extern CLASSDEF_DIRECTX_INPUT       *_MikanInput;
extern CLASSDEF_DIRECTX_SOUND       *_MikanSound;
//extern CLASSDEF_NETWORK             *_MikanNet;
#endif